Read more about this script at
http://techybd.com/2015/10/facebook-phishing-script-2015-3-styles/